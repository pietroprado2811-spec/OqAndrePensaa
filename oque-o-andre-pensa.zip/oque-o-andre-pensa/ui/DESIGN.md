---
name: Warm Editorial Curiosity
colors:
  surface: '#fff8f6'
  surface-dim: '#ffcfc3'
  surface-bright: '#fff8f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff1ed'
  surface-container: '#ffe9e4'
  surface-container-high: '#ffe2db'
  surface-container-highest: '#ffdbd1'
  on-surface: '#380c02'
  on-surface-variant: '#59413a'
  inverse-surface: '#542112'
  inverse-on-surface: '#ffede9'
  outline: '#8d7168'
  outline-variant: '#e1bfb5'
  surface-tint: '#ac3400'
  primary: '#9b2f00'
  on-primary: '#ffffff'
  primary-container: '#c2410c'
  on-primary-container: '#ffece7'
  inverse-primary: '#ffb59d'
  secondary: '#006a63'
  on-secondary: '#ffffff'
  secondary-container: '#99efe5'
  on-secondary-container: '#006f67'
  tertiary: '#784b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#996100'
  on-tertiary-container: '#ffeedd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbd0'
  primary-fixed-dim: '#ffb59d'
  on-primary-fixed: '#390c00'
  on-primary-fixed-variant: '#832600'
  secondary-fixed: '#9cf2e8'
  secondary-fixed-dim: '#80d5cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#00504a'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#fff8f6'
  on-background: '#380c02'
  surface-variant: '#ffdbd1'
typography:
  headline-xl:
    fontFamily: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica,
      Arial, sans-serif
    fontSize: 44px
    fontWeight: '800'
    lineHeight: 52px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica,
      Arial, sans-serif
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 38px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica,
      Arial, sans-serif
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica,
      Arial, sans-serif
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica,
      Arial, sans-serif
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica,
      Arial, sans-serif
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica,
      Arial, sans-serif
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.005em
  body-md:
    fontFamily: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica,
      Arial, sans-serif
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica,
      Arial, sans-serif
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica,
      Arial, sans-serif
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica,
      Arial, sans-serif
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica,
      Arial, sans-serif
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system drives "O que o André pensa?", an editorial and opinion-comparison web application designed to feel like an intimate, witty, and deeply engaging cultural dialogue. The visual direction rejects generic corporate SaaS dashboards, sterile analytics cards, and icy slate tones in favor of an organic, tactile, and warm publication aesthetic.

### Brand Personality & Core Atmosphere
- **Curious & Provocative:** Encourages reflection and counterpoint without aggressive confrontation. Visual treatments invite exploration rather than demanding clinical efficiency.
- **Warm & Tactile:** Grounded in baked-clay tones, sun-drenched creams, and rich earth pigments. Elements look touchable, human, and thoughtfully curated.
- **Irreverent & Conversational:** Asymmetrical card compositions, expressive typographic contrasts, and distinct comparative visual metaphors replace standard enterprise gauges and bar charts.

### Target Audience & Emotional Response
The target audience comprises inquisitive readers, culture and tech enthusiasts, and opinion seekers who value nuanced discourse. The interface must evoke the feeling of stepping into a well-lit personal studio or boutique library—welcoming, intellectually stimulating, and free of bureaucratic noise.

## Colors

The palette establishes two clear dialectical voices while anchoring the overall canvas in rich, warm neutrals. The visual environment avoids pure harsh blacks and cold sterile whites.

### Surface Architecture & Foundations
- **Canvas / Root Background:** Cream (`#FFF7ED`). Sets a luminous, bookish foundation.
- **Primary Surfaces & Content Cards:** Pure White (`#FFFFFF`). Delivers crisp legibility and layered elevation over the cream base.
- **Subtle Containers & Tinted Backdrops:** Soft Peach (`#FFEDD5`). Used for muted highlights, secondary badges, or secondary interactive areas.
- **Borders & Dividers:** Warm Amber Border (`#FED7AA`). Provides soft structural definition without clinical contrast.

### Comparative & Actor Roles
- **Primary Action & Perspective A (André):** Burnt Orange (`#C2410C`). High-contrast, resolute, pairing exclusively with pure white text (`#FFFFFF`) for critical call-to-actions, prominent badges, and active state indicators.
- **Vibrant Accent:** Vivid Orange (`#F97316`). Reserved for reactive interactive states, small playful flourishes, and immediate focal points.
- **Perspective B (The Counterpart / Guest):** Teal Pine (`#0F766E`). Balanced, deep, accessible, pairing with white text (`#FFFFFF`). In charts, this entity always incorporates a secondary visual texture (e.g., repeating diagonal stripes) to ensure non-color-reliant differentiation.
- **Supporting Warmth & Seals:** Amber Gold (`#F59E0B`). Applied to accolades, badges, bookmarks, and subtle notifications.

### Typography & Readability
- **Primary Text & Expressive Headlines:** Espresso Ochre (`#431407`). An earthy dark brown with substantial weight that softens harsh black-on-white reading strain.
- **Secondary & Meta Text:** Warm Earth Gray (`#57534E`). Provides quiet secondary hierarchy with WCAG AA compliance against both `#FFF7ED` and `#FFFFFF`.

### Semantic Messaging & System Feedback
- **Destructive / Error:** `#B91C1C` text and accents over `#FEE2E2` surface.
- **Caution / Alert:** `#92400E` text over `#FEF3C7` surface with a vertical indicator bar in Amber (`#F59E0B`).
- **Affirmative / Success:** `#166534` text and accents over `#DCFCE7` surface.

## Typography

The typography system relies entirely on native system fonts (`-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif`). This ensures instantaneous rendering, zero layout shifts, and native platform fluidity while delivering exceptional readability across hardware.

### Editorial Hierarchy & Rhythm
- **Headlines:** Set with dense weight (700 to 800) and tighter letter tracking to give editorial titles an authoritative, confident presence.
- **Body:** Standardized with open line heights (`1.5` to `1.55`) using `#57534E` for comfortable long-form reading and `#431407` for primary arguments or lead paragraphs.
- **Labels & Micro-copy:** Styled with bold, uppercase, or wide tracking treatments to provide clear signposting on debate tags, categorical pills, and comparative data markers.

## Layout & Spacing

The layout model employs a fluid 12-column responsive grid centered within a maximum container width of `1200px` for standard editorial streams, and `840px` for focused reading views.

### Form Factors & Adaptability
- **Desktop (1024px+):** 12-column layout with 24px (`1.5rem`) gutters and 32px (`2rem`) page margins. Permits asymmetrical side-by-side comparative views (e.g., 6 columns for Perspective A, 6 columns for Perspective B, or 8 columns main discussion and 4 columns context cards).
- **Tablet (768px – 1023px):** 8-column layout with 20px gutters and 24px margins. Two-column split-cards reflow smoothly into stacked or tabbed comparative viewpoints.
- **Mobile (< 768px):** 4-column layout with 16px (`1rem`) gutters and 20px (`1.25rem`) margins. Multi-column comparisons stack vertically or convert into a synchronized swipeable toggle mechanism.

### Spatial Discipline
Spacing follows an organic 4px/8px incremental cadence. Empty space acts as visual pauses, ensuring that lively debates never feel cramped. Section dividers favor generous padding combined with subtle `#FED7AA` separator rules.

## Elevation & Depth

Visual hierarchy is maintained through soft, tactile surface layering rather than intense drop shadows or faux-3D extrusions.

### Tonal Tiers
1. **Level 0 (Canvas):** Flat `#FFF7ED` cream base.
2. **Level 1 (Card & Content Blocks):** Pure white (`#FFFFFF`) surfaces resting with a 1px border of `#FED7AA` and a soft ambient shadow: `box-shadow: 0 4px 16px -2px rgba(67, 20, 7, 0.05)`.
3. **Level 2 (Interactive Floating / Active State):** Raised cards, popovers, and hovering elements lift cleanly: `box-shadow: 0 10px 28px -4px rgba(67, 20, 7, 0.08), 0 2px 6px 0 rgba(67, 20, 7, 0.03)`.
4. **Level 3 (Modals & Overlays):** Deep modal dialogues framed by a translucent warm scrim (`rgba(67, 20, 7, 0.4)`) with: `box-shadow: 0 20px 40px -8px rgba(67, 20, 7, 0.16)`.

Gradients are strictly minimized; when used, they appear solely as faint 2-stop linear washes between `#FFEDD5` and `#FFFFFF` at angles under 45 degrees.

## Shapes

The design system embraces a generous, warm, and friendly shape language. Primary interaction surfaces, dialog cards, and callout sections feature rounded corners ranging from 16px to 20px, mitigating clinical sharpness and inviting user touch.

### Corner Radius Implementation
- **Small Components (Inputs, buttons, small tags):** 8px to 12px radius.
- **Cards & Primary Blocks:** 16px radius (`rounded-lg`), scaling up to 20px (`rounded-xl`) on prominent hero panels.
- **Pills, Badges & Avatars:** Fully circular or 9999px radius (`rounded-full`) for opinion status tags and author avatars.

## Components

### Buttons
- **Primary (Perspective A / André / Call to Action):** Background `#C2410C`, text `#FFFFFF`, font weight 600, padding `0.75rem 1.5rem`, rounded 12px. Hover: `#9A3412`. Active: `#7C2D12`.
- **Secondary (Perspective B / Alternate Action):** Background `#0F766E`, text `#FFFFFF`, rounded 12px. Hover: `#115E59`.
- **Ghost / Tertiary:** Background transparent, text `#C2410C`, border 1.5px solid `#FED7AA`. Hover: background `#FFEDD5`.

### Chips & Badges
- **Editorial Category:** Background `#FFEDD5`, text `#431407`, border 1px solid `#FED7AA`, rounded 9999px, padding `0.25rem 0.75rem`.
- **Perspective A Indicator:** Solid `#C2410C` dot or pill with white text.
- **Perspective B Indicator:** Teal `#0F766E` pill with an underlying diagonal hatch mark icon or pattern to ensure non-color reliance.
- **Amber Seal:** Background `#FEF3C7`, text `#92400E`, border 1px solid `#F59E0B`.

### Comparative Visualizations & Progress Bars
- **Divergent Charts / Bars:**
  - **André / Entity A:** Solid fill in `#C2410C`.
  - **Counterpart / Entity B:** Teal fill in `#0F766E` overlaid with a distinct repeating diagonal CSS stripe pattern (`repeating-linear-gradient(45deg, transparent, transparent 4px, rgba(255,255,255,0.3) 4px, rgba(255,255,255,0.3) 8px)`).
  - Every bar chart requires explicit numeric labels and descriptive text beside the graphic representation to fulfill dual-coding accessibility.

### Cards
- **Editorial Comparison Card:** Background `#FFFFFF`, border 1px solid `#FED7AA`, corner radius 18px, padding 24px (`1.5rem`). Header displays perspective tags side-by-side or stacked with distinct color identities.
- **Quote Callout:** Background `#FFF7ED`, border-left 4px solid `#C2410C`, rounded 0 16px 16px 0, padding 20px.

### Inputs & Controls
- **Text Inputs & Textareas:** Background `#FFFFFF`, border 1.5px solid `#FED7AA`, text `#431407`, placeholder `#57534E` with 50% opacity, rounded 12px, padding `0.75rem 1rem`. Focus state: border-color `#C2410C` with a matching 3px focus ring (`box-shadow: 0 0 0 3px rgba(194, 65, 12, 0.25)`).
- **Checkboxes & Radios:** 20px x 20px, border 2px solid `#FED7AA`, rounded 6px (checkbox) or circular (radio). Checked state: fill `#C2410C` with white checkmark/dot.

### Accessible Focus & Motion Behaviors
- **Universal Focus Ring:** All keyboard-focused interactive components display a visible 3px outline offset by 2px (`outline: 3px solid #C2410C; outline-offset: 2px`). Components tethered to Entity B use `outline: 3px solid #0F766E`.
- **Reduced Motion Support:** Respect `@media (prefers-reduced-motion: reduce)`. All view transitions, expanders, and micro-interactions drop animations and transitions instantly to `0ms`.