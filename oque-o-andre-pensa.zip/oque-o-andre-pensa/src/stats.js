// Estatísticas locais. Regras: curta ≤ 20 chars, longa ≥ 140; nova conversa = pausa ≥ 6h; intervalo médio ignora pausas ≥ 6h.
import { KINDS } from './media.js';
export const LIMITS = { short: 20, long: 140, gapMs: 6 * 3600e3 };
export const PERIODS = ['Madrugada (0–5h)', 'Manhã (6–11h)', 'Tarde (12–17h)', 'Noite (18–23h)'];
const median = (a) => { if (!a.length) return 0; const s = [...a].sort((x, y) => x - y), m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };
export function compute(all, pair) {
  const msgs = all.filter((m) => m.type === 'text' && pair.includes(m.sender)).sort((a, b) => a.date - b.date);
  const per = Object.fromEntries(pair.map((p) => [p, { count: 0, pct: 0, lens: [], short: 0, long: 0, starts: 0, periods: [0, 0, 0, 0] }]));
  const days = new Set(), months = {}, gaps = [];
  msgs.forEach((m, i) => {
    const p = per[m.sender], len = [...m.text].length;
    p.count++; p.lens.push(len); if (len <= LIMITS.short) p.short++; if (len >= LIMITS.long) p.long++;
    p.periods[Math.floor(m.date.getHours() / 6)]++;
    days.add(m.date.toDateString());
    const mk = `${m.date.getFullYear()}-${String(m.date.getMonth() + 1).padStart(2, '0')}`;
    (months[mk] ||= Object.fromEntries(pair.map((x) => [x, 0])))[m.sender]++;
    const gap = i ? m.date - msgs[i - 1].date : Infinity;
    if (gap >= LIMITS.gapMs) p.starts++; else gaps.push(gap);
  });
  const media = Object.fromEntries(pair.map((p) => [p, Object.fromEntries(KINDS.map((k) => [k, 0]))]));
  for (const m of all) if (m.type === 'media' && pair.includes(m.sender)) media[m.sender][m.kind]++;
  const total = msgs.length;
  for (const p of pair) { const s = per[p]; s.pct = total ? (s.count / total) * 100 : 0; s.mean = s.lens.length ? s.lens.reduce((a, b) => a + b, 0) / s.lens.length : 0; s.median = median(s.lens); delete s.lens; }
  return { total, per, media, months, activeDays: days.size, first: msgs[0]?.date, last: msgs.at(-1)?.date, meanGapMin: gaps.length ? gaps.reduce((a, b) => a + b, 0) / gaps.length / 60000 : null };
}
