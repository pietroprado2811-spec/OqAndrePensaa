// Classificação de mídia por nome de arquivo ou marcador do WhatsApp. Só para contagem; mídia nunca é lida nem enviada.
export const KINDS = ['image', 'video', 'audio', 'sticker', 'doc', 'unknown'];
export function mediaKind(s) {
  const t = String(s).toLowerCase();
  if (/sticker|figurinha|stk-|\.webp\b/.test(t)) return 'sticker';
  if (/[aá]udio|\baudio\b|ptt-|aud-|\.(opus|mp3|m4a|aac|ogg|amr|wav)\b/.test(t)) return 'audio';
  if (/v[ií]deo|\bvideo\b|vid-|\.(mp4|mov|3gp|mkv)\b/.test(t)) return 'video';
  if (/imagem|\bimage\b|\bphoto\b|img-|\.(jpe?g|png|heic|gif)\b/.test(t)) return 'image';
  if (/documento|document|\.(pdf|docx?|xlsx?|pptx?|csv)\b/.test(t)) return 'doc';
  return 'unknown';
}
