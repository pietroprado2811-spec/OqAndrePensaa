// Parser WhatsApp (.txt). Estado + regras de continuação; Android ("d/m/y, h:m - ") e iOS ("[d/m/y h:m:s] ").
import { mediaKind } from './media.js';
const INV = /[\u200e\u200f\u202f\u00a0]/g;
const T = String.raw`(\d{1,2})[:.](\d{2})(?:[:.](\d{2}))?\s*([ap]\.?\s?m\.?)?`;
const D = String.raw`(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{2,4})`;
const STARTS = [new RegExp(`^\\[${D},?\\s+${T}\\]\\s*(.*)$`, 'i'), new RegExp(`^${D},?\\s+${T}\\s+[-–—]\\s+(.*)$`, 'i')];
const MEDIA = /(<[^>]*(m[ií]dia|media|anexado|attached)[^>]*>|\(arquivo anexado\)|\b(imagem|figurinha|[aá]udio|v[ií]deo|sticker|image|audio|video) (omitid[ao]|omitted)\b|\.(jpe?g|png|opus|webp|mp4|pdf)\s*\(arquivo)/i;
const DELETED = /^(esta mensagem foi apagada|voc[eê] apagou esta mensagem|this message was deleted)/i;

export function parseWhatsApp(raw) {
  const lines = String(raw).replace(/^\uFEFF/, '').split(/\r?\n/).map((l) => l.replace(INV, ' ').trimEnd());
  const items = []; let cur = null, nonEmpty = 0;
  for (const line of lines) {
    if (!line.trim()) { if (cur) cur.rest += '\n'; continue; }
    nonEmpty++;
    let m = null;
    for (const re of STARTS) if ((m = re.exec(line))) break;
    if (m) { cur = { a: +m[1], b: +m[2], y: +m[3], h: +m[4], mi: +m[5], ap: m[7], rest: m[8] }; items.push(cur); }
    else if (cur) cur.rest += '\n' + line;
  }
  if (!items.length) throw Object.assign(new Error('no-messages'), { code: 'no-messages' });
  if (items.length / nonEmpty < 0.3 && !items.some((i) => i.rest.includes(': '))) throw Object.assign(new Error('format'), { code: 'format' });
  const mdy = items.some((i) => i.b > 12) && !items.some((i) => i.a > 12);
  const ambiguous = !items.some((i) => i.a > 12 || i.b > 12);
  const messages = [], events = [];
  for (const i of items) {
    let h = i.h; const ap = i.ap && i.ap.toLowerCase()[0];
    if (ap === 'p' && h < 12) h += 12; if (ap === 'a' && h === 12) h = 0;
    const [day, mon] = mdy ? [i.b, i.a] : [i.a, i.b];
    const date = new Date(i.y < 100 ? 2000 + i.y : i.y, mon - 1, day, h, i.mi);
    const rest = i.rest.trim(), k = rest.indexOf(': ');
    if (k > 0 && k <= 60 && !rest.slice(0, k).includes('\n')) {
      const text = rest.slice(k + 2).trim();
      messages.push({ date, sender: rest.slice(0, k).replace(/^~\s*/, '').trim(), text, type: DELETED.test(text) ? 'deleted' : MEDIA.test(text) ? 'media' : 'text', ...(MEDIA.test(text) && !DELETED.test(text) ? { kind: mediaKind(text) } : {}) });
    } else events.push({ date, text: rest });
  }
  return { messages, events, ambiguousDate: ambiguous, dateOrder: mdy ? 'MDY' : 'DMY' };
}
