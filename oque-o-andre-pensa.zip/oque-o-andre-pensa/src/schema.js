// Fonte única de verdade do contrato JSON (validação runtime estrita; sem campos extras).
const WHO = ['Pessoa A', 'Pessoa B', 'Equilibrado', 'Inconclusivo'], SP = ['Pessoa A', 'Pessoa B'];
const str = (v, max) => typeof v === 'string' && v.trim().length > 0 && v.length <= max;
const arr = (v, max, f) => Array.isArray(v) && v.length <= max && v.every(f);
const score = (v) => Number.isInteger(v) && v >= 1 && v <= 10;
const obj = (v, keys) => v && typeof v === 'object' && !Array.isArray(v) && Object.keys(v).length === keys.length && keys.every((k) => k in v);
export function validateReport(r) {
  const K = ['vibe_tags', 'interest_score_person_a', 'interest_score_person_b', 'who_pushed_more', 'funny_verdict', 'top_highlights', 'conversation_report', 'analysis_notes'];
  const ok = obj(r, K) && arr(r.vibe_tags, 8, (s) => str(s, 40)) && score(r.interest_score_person_a) && score(r.interest_score_person_b) && WHO.includes(r.who_pushed_more) && str(r.funny_verdict, 400)
    && arr(r.top_highlights, 6, (h) => obj(h, ['speaker', 'quote', 'why_it_matters']) && SP.includes(h.speaker) && str(h.quote, 300) && str(h.why_it_matters, 250))
    && arr(r.conversation_report, 12, (c) => obj(c, ['topic', 'summary', 'tone']) && str(c.topic, 80) && str(c.summary, 500) && str(c.tone, 40))
    && arr(r.analysis_notes, 8, (s) => str(s, 300));
  return ok ? { ok: true, value: r } : { ok: false };
}
export function parseModelJson(text) {
  try { return JSON.parse(text.trim().replace(/^```(?:json)?\s*|\s*```$/g, '')); } catch { return null; }
}
