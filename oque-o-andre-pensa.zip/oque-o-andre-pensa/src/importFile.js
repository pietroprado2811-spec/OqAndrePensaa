// Ponto de entrada de importação: aceita .zip (com ou sem mídia) ou .txt. Tudo local.
import { readZip, ZIP_LIMITS } from './zip.js';
export const IMPORT_ERRORS = { ext: 'Formato não aceito: envie o .zip ou o .txt exportado do WhatsApp.', zip: 'Não consegui abrir o .zip. Exporte de novo ou envie só o .txt de dentro.', zip64: 'Zip grande demais para ler aqui. Exporte "sem mídia" ou envie só o .txt.', 'zip-big': 'O zip tem arquivos demais. Exporte "sem mídia" ou envie só o .txt.', 'no-txt': 'Não encontrei o arquivo de conversa (.txt) dentro do zip.', 'too-big': `O texto da conversa passa do limite de ${ZIP_LIMITS.maxTextBytes / 1048576} MB. Exporte um período menor.` };
export async function importFile(file) {
  if (/\.zip$/i.test(file.name)) { const z = await readZip(file); return { text: z.text, source: 'zip', mediaFiles: z.mediaFiles, totalFiles: z.totalFiles }; }
  if (/\.txt$/i.test(file.name)) {
    if (file.size > ZIP_LIMITS.maxTextBytes) throw Object.assign(new Error('too-big'), { code: 'too-big' });
    return { text: await file.text(), source: 'txt', mediaFiles: null, totalFiles: 0 };
  }
  throw Object.assign(new Error('ext'), { code: 'ext' });
}
