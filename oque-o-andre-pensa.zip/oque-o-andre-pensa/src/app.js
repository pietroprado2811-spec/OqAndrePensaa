import { parseWhatsApp } from './parser.js'; import { compute, PERIODS, LIMITS } from './stats.js'; import { buildPayload } from './privacy.js'; import { importFile, IMPORT_ERRORS } from './importFile.js';
import { callGemini, DEFAULT_MODEL, ERRORS } from './gemini.js'; import { validateReport, parseModelJson } from './schema.js';
const app = document.getElementById('app');
const h = (t, p = {}, ...c) => { const e = document.createElement(t); for (const [k, v] of Object.entries(p)) k === 'class' ? (e.className = v) : k.startsWith('on') ? e.addEventListener(k.slice(2), v) : e.setAttribute(k, v); e.append(...c.flat().filter((x) => x != null && x !== false)); return e; };
const ic = (n) => h('span', { class: 'material-symbols-outlined text-[20px]', 'aria-hidden': 'true' }, n);
const CARD = 'rounded-[18px] bg-surface-container-lowest p-space-lg shadow-[0_4px_20px_-2px_rgba(67,20,7,0.06)] flex flex-col gap-space-sm';
const BTN = 'h-12 px-space-md flex items-center justify-center gap-space-sm bg-primary text-on-primary rounded-xl font-label-lg text-label-lg disabled:opacity-50 disabled:cursor-not-allowed', GHOST = 'h-12 px-space-md rounded-xl border border-outline text-on-surface font-label-lg text-label-lg';
const INPUT = 'w-full rounded-xl border border-outline bg-surface-container-lowest p-space-sm text-body-md';
const BANNER = { info: 'bg-tertiary-fixed/40 text-on-surface', warn: 'bg-tertiary-fixed text-on-tertiary-fixed', err: 'bg-error-container text-on-error-container' };
const banner = (kind, icon, ...t) => h('div', { class: `rounded-[18px] p-space-md flex gap-space-sm items-start text-body-sm ${BANNER[kind]}`, ...(kind === 'err' ? { role: 'alert' } : {}) }, ic(icon), h('div', {}, ...t));
const card = (title, ...c) => h('section', { class: CARD }, title && h('h2', { class: 'font-headline-sm text-label-lg font-bold' }, title), ...c);
const fresh = () => ({ stage: 'start', msg: '', imp: null, parsed: null, names: {}, pair: [], stats: null, pl: null, text: '', key: '', model: DEFAULT_MODEL, agree: false, report: null, ctl: null });
let S = fresh();
const go = (stage, msg = '') => { S.stage = stage; S.msg = msg; render(); window.scrollTo(0, 0); };
const reset = () => { S.ctl?.abort(); S = fresh(); render(); };
const dn = (t) => String(t).replaceAll('Pessoa A', S.names[S.pair[0]] || 'Pessoa A').replaceAll('Pessoa B', S.names[S.pair[1]] || 'Pessoa B');
const fd = (d) => (d ? d.toLocaleDateString('pt-BR') : '—'), n1 = (x) => (Math.round(x * 10) / 10).toLocaleString('pt-BR'), pct = (x, t) => (t ? Math.round((x / t) * 100) : 0);
const STRIPE = 'bg-[repeating-linear-gradient(45deg,#006a63,#006a63_4px,#80d5cb_4px,#80d5cb_8px)]';
const bar = (label, a, b) => h('div', { class: 'flex flex-col gap-1' }, h('div', { class: 'flex justify-between text-label-md gap-2' }, h('span', {}, label), h('span', {}, `${dn('Pessoa A')} ${a}% · ${dn('Pessoa B')} ${b}%`)),
  h('div', { class: 'flex h-4 rounded-full overflow-hidden bg-surface-container-high', role: 'img', 'aria-label': `${label}: ${dn('Pessoa A')} ${a}%, ${dn('Pessoa B')} ${b}%` }, ...[[a, 'bg-primary'], [b, STRIPE]].map(([w, c]) => { const i = h('i', { class: `block h-full ${c}` }); i.style.width = w + '%'; return i; })));

async function onFile(file) {
  if (!file) return;
  if (file.size === 0) return go('start', 'O arquivo está vazio.');
  S.stage = 'loading'; render();
  try {
    const imp = await importFile(file);
    if ((imp.text.match(/\uFFFD/g) || []).length > imp.text.length * 0.01) return go('start', 'A codificação do arquivo parece incorreta. Exporte de novo do WhatsApp (UTF-8).');
    const parsed = parseWhatsApp(imp.text), count = {};
    parsed.messages.filter((m) => m.type === 'text').forEach((m) => (count[m.sender] = (count[m.sender] || 0) + 1));
    const people = Object.keys(count).sort((a, b) => count[b] - count[a]);
    if (people.length < 2) return go('start', 'Só encontrei um participante com mensagens de texto. Preciso de pelo menos dois.');
    Object.assign(S, { imp, parsed, count, people, pair: people.slice(0, 2), names: Object.fromEntries(people.map((p) => [p, p])) }); go('pick');
  } catch (e) { go('start', IMPORT_ERRORS[e.code] || (e.code === 'format' || e.code === 'no-messages' ? 'Não reconheci o formato de exportação do WhatsApp. Tente exportar de novo.' : 'Não consegui ler o arquivo.')); }
}
function calc() { S.stats = compute(S.parsed.messages, S.pair); if (S.stats.total < 2) return go('pick', 'Poucas mensagens de texto entre essas duas pessoas.'); S.pl = buildPayload(S.parsed.messages, S.pair); S.text = S.pl.text; go('review'); }
async function send() {
  S.ctl = new AbortController(); go('sending');
  try {
    let rep = null;
    for (let i = 0; i < 2 && !rep; i++) { const v = validateReport(parseModelJson(await callGemini({ key: S.key, model: S.model, payload: S.text, signal: S.ctl.signal }))); if (v.ok) rep = v.value; }
    if (!rep) throw { code: 'invalid' };
    S.report = rep; go('report');
  } catch (e) { go('error', ERRORS[e.code] || 'A resposta do Gemini veio fora do formato esperado. Tente novamente.'); }
}
const MK = [['image', 'Fotos'], ['video', 'Vídeos'], ['audio', 'Áudios'], ['sticker', 'Figurinhas'], ['doc', 'Documentos'], ['unknown', 'Não identificadas']];
function statsView() {
  const s = S.stats, [A, B] = S.pair, a = s.per[A], b = s.per[B], months = Object.entries(s.months).sort();
  const rows = [['Mensagens', 'count'], ['Participação (%)', 'pct'], ['Média de caracteres', 'mean'], ['Mediana de caracteres', 'median'], [`Curtas (≤${LIMITS.short})`, 'short'], [`Longas (≥${LIMITS.long})`, 'long'], ['Retomadas (pausa ≥6h)', 'starts']];
  const cell = 'py-1 pr-2 text-left';
  return [card('Estatísticas (calculadas no seu navegador)', h('p', { class: 'text-body-sm text-on-surface-variant' }, `${s.total} mensagens de texto · ${s.activeDays} dias ativos · de ${fd(s.first)} a ${fd(s.last)}` + (s.meanGapMin != null ? ` · intervalo médio: ${n1(s.meanGapMin)} min` : '')),
    h('table', { class: 'w-full text-body-sm' }, h('caption', { class: 'sr-only' }, 'Comparação entre as duas pessoas'), h('tr', {}, h('th', { class: cell }, ''), h('th', { class: cell }, dn('Pessoa A')), h('th', { class: cell }, dn('Pessoa B'))), rows.map(([l, k]) => h('tr', { class: 'border-t border-outline-variant' }, h('th', { scope: 'row', class: cell + ' font-normal' }, l), h('td', { class: cell }, n1(a[k])), h('td', { class: cell }, n1(b[k]))))),
    h('h3', { class: 'font-label-lg text-label-lg font-bold mt-space-sm' }, 'Por período do dia'), PERIODS.map((p, i) => bar(p, pct(a.periods[i], a.count), pct(b.periods[i], b.count))),
    h('h3', { class: 'font-label-lg text-label-lg font-bold mt-space-sm' }, 'Proporção por mês'), months.map(([m, v]) => bar(m, pct(v[A], v[A] + v[B]), pct(v[B], v[A] + v[B]))),
    h('p', { class: 'text-label-sm text-on-surface-variant' }, 'Barra cheia = Pessoa A · barra listrada = Pessoa B. Mídias omitidas, mensagens apagadas e exportações incompletas não entram na conta.')),
  card('Mídias', h('table', { class: 'w-full text-body-sm' }, h('tr', {}, h('th', { class: cell }, ''), h('th', { class: cell }, dn('Pessoa A')), h('th', { class: cell }, dn('Pessoa B'))), MK.filter(([k]) => s.media[A][k] + s.media[B][k] > 0).map(([k, l]) => h('tr', { class: 'border-t border-outline-variant' }, h('th', { scope: 'row', class: cell + ' font-normal' }, l), h('td', { class: cell }, s.media[A][k]), h('td', { class: cell }, s.media[B][k])))),
    h('p', { class: 'text-label-sm text-on-surface-variant' }, 'Contagem local pelos marcadores do texto' + (S.imp?.mediaFiles ? `; o zip trouxe ${S.imp.totalFiles} arquivos. O WhatsApp pode exportar menos arquivos que o histórico.` : '.') + ' Mídia não é enviada à IA.'))];
}
function pick() {
  const sel = (i) => h('label', { class: 'flex flex-col gap-1 text-label-md' }, `Pessoa ${'AB'[i]}`, h('select', { class: INPUT, onchange: (e) => (S.pair[i] = e.target.value) }, S.people.map((p) => h('option', { value: p, ...(p === S.pair[i] ? { selected: '' } : {}) }, p))));
  return [card('Quem está nessa conversa?', S.msg && banner('err', 'error', S.msg), S.parsed.ambiguousDate && banner('warn', 'calendar_clock', 'Datas ambíguas: assumi dia/mês/ano.'),
    h('p', { class: 'text-body-sm text-on-surface-variant' }, 'Renomear vale só para exibição. Os nomes originais nunca vão para a IA.'),
    S.people.map((p) => h('label', { class: 'flex flex-col gap-1 text-label-md' }, `${p} · ${S.count[p]} msgs`, h('input', { type: 'text', maxlength: '20', class: INPUT, value: S.names[p], 'aria-label': `Nome de exibição para ${p}`, oninput: (e) => (S.names[p] = e.target.value) }))),
    h('div', { class: 'grid grid-cols-2 gap-space-sm' }, sel(0), sel(1)),
    h('div', { class: 'flex gap-space-sm' }, h('button', { class: GHOST, onclick: reset }, 'Voltar'), h('button', { class: BTN + ' flex-1', onclick: () => (S.pair[0] === S.pair[1] ? go('pick', 'Escolha duas pessoas diferentes.') : calc()) }, 'Calcular estatísticas', ic('analytics'))))];
}
function review() {
  const pl = S.pl, btn = h('button', { class: BTN + ' flex-1', disabled: '' }, 'Enviar ao Gemini', ic('send'));
  const upd = () => { btn.disabled = !(S.agree && S.key.trim() && S.text.trim() && S.model.trim()); }; btn.onclick = send; upd();
  return [...statsView(), card('Revise o que será enviado', banner('warn', 'privacy_tip', 'Seu arquivo foi processado localmente e não será enviado como arquivo. Este texto anonimizado (incluindo trechos que podem virar destaques) será enviado ao Google Gemini. A anonimização automática pode não remover tudo: leia e edite abaixo.'),
    pl.sampled && banner('info', 'info', `Conversa extensa: usei amostragem (${pl.used} de ${pl.total} mensagens: começo, meio e fim).`),
    pl.sensitive.length > 0 && banner('err', 'warning', `Possíveis dados sensíveis (${pl.sensitive.join(', ')}). Remova esses trechos ou cancele.`),
    h('label', { class: 'flex flex-col gap-1 text-label-md' }, 'Material anonimizado (editável)', h('textarea', { class: INPUT + ' min-h-[220px] text-body-sm', oninput: (e) => { S.text = e.target.value; upd(); } }, S.text)),
    h('label', { class: 'flex flex-col gap-1 text-label-md' }, 'Chave da API Gemini (fica só na memória desta aba; você responde pela chave e pela cota)', h('input', { type: 'password', autocomplete: 'off', class: INPUT, oninput: (e) => { S.key = e.target.value; upd(); } })),
    h('label', { class: 'flex flex-col gap-1 text-label-md' }, 'Modelo', h('input', { type: 'text', class: INPUT, value: S.model, oninput: (e) => { S.model = e.target.value; upd(); } })),
    h('label', { class: 'flex gap-space-sm items-start text-body-sm' }, h('input', { type: 'checkbox', class: 'mt-1 w-5 h-5 accent-[#9b2f00]', onchange: (e) => { S.agree = e.target.checked; upd(); } }), 'Li o material e autorizo o envio ao Google Gemini.'),
    h('div', { class: 'flex gap-space-sm' }, h('button', { class: GHOST, onclick: reset }, 'Cancelar e limpar tudo'), btn))];
}
function report() {
  const r = S.report, st = S.stats, sc = (p, v) => h('div', { class: 'flex-1 rounded-xl bg-surface-container p-space-md text-center' }, h('div', { class: 'text-[40px] font-extrabold text-primary' }, `${v}/10`), h('div', { class: 'text-label-md' }, dn(p)));
  return [card('Resumo da conversa', h('p', {}, `${st.total} mensagens entre ${dn('Pessoa A')} e ${dn('Pessoa B')}, em ${st.activeDays} dias ativos.`), h('p', { class: 'text-on-surface-variant' }, dn(r.conversation_report.map((c) => c.topic).join(' → ')))), ...statsView(),
    card('Clima da conversa', h('div', { class: 'flex flex-wrap gap-2' }, r.vibe_tags.map((t) => h('span', { class: 'rounded-full bg-surface-container-high text-primary px-3 py-1 text-label-md' }, dn(t))))),
    card('Nível de iniciativa', h('div', { class: 'flex gap-space-sm' }, sc('Pessoa A', r.interest_score_person_a), sc('Pessoa B', r.interest_score_person_b)), h('p', { class: 'text-label-sm text-on-surface-variant' }, 'Estimativas recreativas baseadas só no texto recebido, não medidas científicas.')),
    card('Quem correu mais atrás?', h('p', { class: 'text-headline-lg-mobile font-bold text-primary' }, dn(r.who_pushed_more)), r.analysis_notes.map((n) => h('p', { class: 'text-body-sm' }, dn(n)))),
    card('Veredito', h('p', { class: 'text-body-md font-semibold' }, dn(r.funny_verdict))),
    card('Momentos marcantes', r.top_highlights.length ? r.top_highlights.map((x) => h('blockquote', { class: 'border-l-4 border-primary-container pl-space-sm' }, h('strong', {}, dn(x.speaker) + ': '), `“${dn(x.quote)}”`, h('br'), h('small', { class: 'text-on-surface-variant' }, dn(x.why_it_matters)))) : h('p', {}, 'Sem destaques.')),
    card('Relatório por tópicos', h('ul', { class: 'list-disc pl-5 flex flex-col gap-2' }, r.conversation_report.map((c) => h('li', {}, h('strong', {}, dn(c.topic)), ` (${dn(c.tone)}): ${dn(c.summary)}`)))),
    card('Limitações da análise', h('p', { class: 'text-body-sm' }, `O resultado depende do arquivo e do contexto disponível${S.pl?.sampled ? ' e usou amostragem' : ''}. Frequência de mensagens não prova interesse. A IA pode errar. Entretenimento, não diagnóstico.`)),
    h('button', { class: BTN, onclick: reset }, 'Nova análise (limpar dados e chave)')];
}
const spin = (txt, ...x) => h('section', { class: CARD + ' items-center text-center' }, h('div', { class: 'w-10 h-10 rounded-full border-4 border-surface-container-high border-t-primary animate-spin' }), h('p', { class: 'font-semibold' }, txt), ...x);
const views = {
  start: () => [h('section', { class: 'flex flex-col gap-space-xs pt-space-xs' }, h('div', { class: 'inline-flex self-start items-center gap-space-xs px-space-md py-1 rounded-full bg-surface-container-high text-primary text-label-md' }, ic('lock'), '100% processamento local'), h('h1', { class: 'text-headline-lg-mobile font-bold tracking-tight' }, 'O que o André pensa?'), h('p', { class: 'text-on-surface-variant' }, 'O arquivo fica guardadinho no seu navegador e nada vai à IA sem o seu consentimento. As contas são feitas aqui mesmo.')),
    h('label', { class: CARD + ' items-center text-center cursor-pointer focus-within:outline focus-within:outline-[3px] focus-within:outline-secondary', ondragover: (e) => e.preventDefault(), ondrop: (e) => { e.preventDefault(); onFile(e.dataTransfer.files[0]); } }, h('div', { class: 'w-20 h-20 rounded-full bg-surface-container-high text-primary flex items-center justify-center' }, h('span', { class: 'material-symbols-outlined text-[36px]', 'aria-hidden': 'true' }, 'folder_zip')),
      h('p', { class: 'font-headline-sm text-label-lg font-bold' }, 'Arraste seu arquivo .zip ou .txt aqui'), h('p', { class: 'text-body-sm text-on-surface-variant' }, 'Exporte o chat no WhatsApp com ou sem mídia'), h('span', { class: BTN + ' w-full max-w-xs' }, ic('upload_file'), 'Ou selecione do dispositivo'), h('input', { class: 'sr-only', type: 'file', accept: '.zip,.txt', onchange: (e) => onFile(e.target.files[0]) })),
    S.msg && banner('err', 'error', S.msg), banner('info', 'privacy_tip', 'Fotos, áudios e vídeos do zip não são abertos nem enviados à IA: só contados, localmente.')],
  loading: () => [spin('Lendo o arquivo no seu navegador…')], pick, review, report,
  sending: () => [spin('Consultando o Gemini…', h('button', { class: GHOST, onclick: () => S.ctl.abort() }, 'Cancelar'))],
  error: () => [banner('err', 'error', S.msg), h('div', { class: 'flex gap-space-sm' }, S.pl && h('button', { class: BTN + ' flex-1', onclick: () => go('review') }, 'Voltar à revisão'), h('button', { class: GHOST, onclick: reset }, 'Reiniciar'))],
};
function render() { app.replaceChildren(...views[S.stage]().filter(Boolean)); }
window.addEventListener('pagehide', () => { S = fresh(); });
render();
