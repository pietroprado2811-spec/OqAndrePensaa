// Anonimização local. É "melhor esforço": não garante remover tudo (nomes de terceiros, locais etc. podem escapar).
const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const RULES = [[/https?:\/\/\S+|www\.\S+/gi, '[link]'], [/[\w.+-]+@[\w-]+\.[\w.-]+/g, '[email]'], [/\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b/g, '[documento]'], [/\+?\d[\d\s().-]{7,}\d/g, '[telefone]'], [/@[\w.]+/g, '[usuário]']];
const SENSITIVE = /\b(senha|cpf|cart[aã]o|cvv|pix|conta banc[aá]ria|diagn[oó]stico|rem[eé]dio|depress[aã]o|suic[ií]d\w*)\b/gi;
export const MAX_MESSAGES = 400, MAX_QUOTE = 300;
export function anonymizeText(text, nameMap) {
  let t = text;
  const pairs = Object.entries(nameMap).flatMap(([n, r]) => [[n, r], ...n.split(/\s+/).filter((w) => w.length >= 3).map((w) => [w, r])]).sort((a, b) => b[0].length - a[0].length);
  for (const [n, r] of pairs) t = t.replace(new RegExp(`(?<![\\p{L}\\d])${esc(n)}(?![\\p{L}\\d])`, 'giu'), r);
  for (const [re, r] of RULES) t = t.replace(re, r);
  return t.replace(/\s+/g, ' ').trim().slice(0, MAX_QUOTE);
}
export function sample(msgs, max = MAX_MESSAGES) {
  if (msgs.length <= max) return msgs;
  const head = 100, tail = 100, mid = max - head - tail, span = msgs.length - head - tail;
  return [...msgs.slice(0, head), ...Array.from({ length: mid }, (_, i) => msgs[head + Math.floor((i * span) / mid)]), ...msgs.slice(-tail)];
}
export function buildPayload(all, pair) {
  const nameMap = { [pair[0]]: 'Pessoa A', [pair[1]]: 'Pessoa B' };
  const msgs = all.filter((m) => m.type === 'text' && pair.includes(m.sender)).sort((a, b) => a.date - b.date);
  const used = sample(msgs), day0 = msgs[0] ? new Date(msgs[0].date.toDateString()) : 0;
  const lines = used.map((m) => `[Dia ${Math.round((new Date(m.date.toDateString()) - day0) / 864e5) + 1}] ${nameMap[m.sender]}: ${anonymizeText(m.text, nameMap)}`);
  const text = `Conversa anonimizada entre Pessoa A e Pessoa B. Dias são relativos ao primeiro dia. Amostra: ${used.length} de ${msgs.length} mensagens.\n` + lines.join('\n');
  return { text, sampled: used.length < msgs.length, total: msgs.length, used: used.length, sensitive: [...new Set((text.match(SENSITIVE) || []).map((s) => s.toLowerCase()))] };
}
