// Leitor mínimo de .zip no navegador (stored/deflate, sem zip64). Só lê o diretório central e o .txt do chat; mídias nunca são descompactadas.
import { KINDS, mediaKind } from './media.js';
export const ZIP_LIMITS = { maxEntries: 50000, maxTextBytes: 5 * 1024 * 1024 };
const zerr = (code) => Object.assign(new Error(code), { code });
const u16 = (d, o) => d.getUint16(o, true), u32 = (d, o) => d.getUint32(o, true);
async function inflate(bytes, limit) {
  const r = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw')).getReader(), parts = []; let n = 0;
  for (;;) { const { done, value } = await r.read(); if (done) break; n += value.length; if (n > limit) { await r.cancel(); throw zerr('too-big'); } parts.push(value); }
  return new Blob(parts).arrayBuffer();
}
export async function readZip(blob, maxText = ZIP_LIMITS.maxTextBytes) {
  const size = blob.size; if (size < 22) throw zerr('zip');
  const tl = Math.min(size, 22 + 65535), tail = new DataView(await blob.slice(size - tl).arrayBuffer());
  let e = -1; for (let i = tl - 22; i >= 0; i--) if (u32(tail, i) === 0x06054b50) { e = i; break; }
  if (e < 0) throw zerr('zip');
  const count = u16(tail, e + 10), cdSize = u32(tail, e + 12), cdOff = u32(tail, e + 16);
  if (count === 0xffff || cdSize === 0xffffffff || cdOff === 0xffffffff) throw zerr('zip64');
  if (count > ZIP_LIMITS.maxEntries) throw zerr('zip-big');
  const cd = new DataView(await blob.slice(cdOff, cdOff + cdSize).arrayBuffer()), dec = new TextDecoder('utf-8'), entries = []; let p = 0;
  for (let i = 0; i < count; i++) {
    if (p + 46 > cd.byteLength || u32(cd, p) !== 0x02014b50) throw zerr('zip');
    const nl = u16(cd, p + 28), xl = u16(cd, p + 30), cl = u16(cd, p + 32);
    entries.push({ method: u16(cd, p + 10), csize: u32(cd, p + 20), usize: u32(cd, p + 24), lho: u32(cd, p + 42), name: dec.decode(new Uint8Array(cd.buffer, p + 46, nl)) });
    p += 46 + nl + xl + cl;
  }
  const files = entries.filter((x) => !x.name.endsWith('/') && !x.name.startsWith('__MACOSX/'));
  const txts = files.filter((x) => /\.txt$/i.test(x.name));
  const base = (n) => n.split('/').pop();
  const chat = txts.find((x) => /^_chat\.txt$/i.test(base(x.name))) || txts.find((x) => /^(conversa do whatsapp|whatsapp chat)/i.test(base(x.name))) || [...txts].sort((a, b) => b.usize - a.usize)[0];
  if (!chat) throw zerr('no-txt');
  if (chat.usize > maxText || chat.csize > maxText) throw zerr('too-big');
  const lh = new DataView(await blob.slice(chat.lho, chat.lho + 30).arrayBuffer());
  if (u32(lh, 0) !== 0x04034b50) throw zerr('zip');
  const start = chat.lho + 30 + u16(lh, 26) + u16(lh, 28), raw = await blob.slice(start, start + chat.csize).arrayBuffer();
  let buf; if (chat.method === 0) buf = raw; else if (chat.method === 8) buf = await inflate(new Uint8Array(raw), maxText); else throw zerr('zip');
  if (buf.byteLength > maxText) throw zerr('too-big');
  const media = Object.fromEntries(KINDS.map((k) => [k, 0]));
  for (const f of files) if (f !== chat && !/\.txt$/i.test(f.name)) media[mediaKind(f.name)]++;
  return { text: new TextDecoder('utf-8').decode(buf), chatName: base(chat.name), mediaFiles: media, totalFiles: files.length - 1 };
}
