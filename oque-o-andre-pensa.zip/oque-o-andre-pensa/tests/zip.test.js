import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs'; import { deflateRawSync } from 'node:zlib';
import { readZip } from '../src/zip.js'; import { parseWhatsApp } from '../src/parser.js'; import { compute } from '../src/stats.js'; import { mediaKind } from '../src/media.js';
const enc = new TextEncoder();
function zip(entries) { // entries: {name, data, deflate?, lieUsize?}
  const out = [], cd = []; let off = 0;
  for (const e of entries) {
    const n = enc.encode(e.name), raw = Buffer.from(e.data), data = e.deflate ? deflateRawSync(raw) : raw, us = e.lieUsize ?? raw.length;
    const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(e.deflate ? 8 : 0, 8); lh.writeUInt32LE(data.length, 18); lh.writeUInt32LE(us, 22); lh.writeUInt16LE(n.length, 26);
    const ch = Buffer.alloc(46); ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(e.deflate ? 8 : 0, 10); ch.writeUInt32LE(data.length, 20); ch.writeUInt32LE(us, 24); ch.writeUInt16LE(n.length, 28); ch.writeUInt32LE(off, 42);
    out.push(lh, Buffer.from(n), data); cd.push(ch, Buffer.from(n)); off += 30 + n.length + data.length;
  }
  const cdb = Buffer.concat(cd), end = Buffer.alloc(22); end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(entries.length, 10); end.writeUInt32LE(cdb.length, 12); end.writeUInt32LE(off, 16);
  return new Blob([Buffer.concat([...out, cdb, end])]);
}
const chat = readFileSync(new URL('./fixture.txt', import.meta.url));
test('zip: lê o chat e conta mídias por nome de arquivo', async () => {
  const z = await readZip(zip([{ name: 'Conversa/_chat.txt', data: chat, deflate: true }, { name: 'IMG-1.jpg', data: 'x' }, { name: 'STK-1.webp', data: 'x' }, { name: 'PTT-1.opus', data: 'x' }, { name: 'VID-1.mp4', data: 'x' }, { name: '__MACOSX/._a.jpg', data: 'x' }]));
  assert.equal(z.text, chat.toString('utf8')); assert.deepEqual([z.mediaFiles.image, z.mediaFiles.sticker, z.mediaFiles.audio, z.mediaFiles.video], [1, 1, 1, 1]);
});
test('zip: erros controlados', async () => {
  await assert.rejects(readZip(new Blob(['nada de zip aqui, so texto comum'])), { code: 'zip' });
  await assert.rejects(readZip(zip([{ name: 'a.jpg', data: 'x' }])), { code: 'no-txt' });
  await assert.rejects(readZip(zip([{ name: '_chat.txt', data: Buffer.alloc(6e6), deflate: true, lieUsize: 10 }]), 5e6), { code: 'too-big' });
});
test('mídia: classificação e contagem por pessoa', () => {
  assert.equal(mediaKind('IMG-20240305-WA0001.jpg (arquivo anexado)'), 'image'); assert.equal(mediaKind('<anexado: 0001-STICKER-x.webp>'), 'sticker'); assert.equal(mediaKind('<Mídia oculta>'), 'unknown');
  const p = parseWhatsApp('05/03/2024 21:15 - Ana: oi\n05/03/2024 21:16 - Beto: PTT-1.opus (arquivo anexado)\n05/03/2024 21:17 - Ana: <anexado: 0002-PHOTO-a.jpg>');
  const s = compute(p.messages, ['Ana', 'Beto']); assert.equal(s.media.Beto.audio, 1); assert.equal(s.media.Ana.image, 1);
});
