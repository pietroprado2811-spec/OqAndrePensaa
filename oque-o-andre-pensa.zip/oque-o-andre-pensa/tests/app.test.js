import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import { parseWhatsApp } from '../src/parser.js'; import { compute } from '../src/stats.js'; import { buildPayload, anonymizeText, sample } from '../src/privacy.js'; import { validateReport, parseModelJson } from '../src/schema.js';
const raw = readFileSync(new URL('./fixture.txt', import.meta.url), 'utf8'), p = parseWhatsApp(raw);
test('parser: multilinha, sistema, mídia', () => {
  assert.equal(p.events.length, 1); assert.equal(p.messages.length, 5);
  assert.equal(p.messages[1].text, 'Tudo sim 😄\ne você?'); assert.equal(p.messages[2].type, 'media');
});
test('parser: iOS e erros', () => {
  assert.equal(parseWhatsApp('[13/03/24, 21:14:05] Ana: oi').messages[0].sender, 'Ana');
  assert.throws(() => parseWhatsApp('qualquer coisa'), { code: 'no-messages' });
});
test('stats', () => {
  const s = compute(p.messages, ['Ana Souza', 'Beto']);
  assert.equal(s.total, 4); assert.equal(s.per['Ana Souza'].count, 2); assert.equal(s.activeDays, 3); assert.equal(s.per.Beto.pct, 50);
});
test('anonimização', () => {
  const t = buildPayload(p.messages, ['Ana Souza', 'Beto']).text;
  for (const bad of ['Ana', 'Beto', 'beto@', '91234', 'https://']) assert.ok(!t.includes(bad), bad);
  assert.equal(anonymizeText('Oi Ana Souza', { 'Ana Souza': 'Pessoa A' }), 'Oi Pessoa A');
  assert.equal(sample(Array.from({ length: 1000 }, (_, i) => i)).length, 400);
});
test('schema', () => {
  const ok = { vibe_tags: ['x'], interest_score_person_a: 7, interest_score_person_b: 5, who_pushed_more: 'Pessoa A', funny_verdict: 'v', top_highlights: [], conversation_report: [], analysis_notes: [] };
  assert.ok(validateReport(ok).ok); assert.ok(!validateReport({ ...ok, interest_score_person_a: 11 }).ok); assert.ok(!validateReport({ ...ok, extra: 1 }).ok);
  assert.deepEqual(parseModelJson('```json\n{"a":1}\n```'), { a: 1 }); assert.equal(parseModelJson('{x'), null);
});
